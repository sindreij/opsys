javac *.java
java Simulator
