javac *.java
java Simulator
